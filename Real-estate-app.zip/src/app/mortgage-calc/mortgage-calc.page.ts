import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mortgage-calc',
  templateUrl: './mortgage-calc.page.html',
  styleUrls: ['./mortgage-calc.page.scss'],
})
export class MortgageCalcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
