export interface Coord {
  lat: number;
  lng: number;
}
