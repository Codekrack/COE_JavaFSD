export default [
  {
    city: 'Manila',
    lat: '14.6000',
    lng: '120.9833',
  },
  {
    city: 'Quezon City',
    lat: '14.6333',
    lng: '121.0333',
  },
  {
    city: 'Davao',
    lat: '7.0667',
    lng: '125.6000',
  },
  {
    city: 'Caloocan City',
    lat: '14.6500',
    lng: '120.9667',
  },
  {
    city: 'Cebu City',
    lat: '10.3000',
    lng: '123.9000',
  },
  {
    city: 'Zamboanga City',
    lat: '6.9167',
    lng: '122.0833',
  },
  {
    city: 'Taguig City',
    lat: '14.5167',
    lng: '121.0500',
  },
  {
    city: 'Antipolo',
    lat: '14.5842',
    lng: '121.1763',
  },
  {
    city: 'Pasig City',
    lat: '14.5750',
    lng: '121.0833',
  },
  {
    city: 'Cagayan de Oro',
    lat: '8.4833',
    lng: '124.6500',
  },
  {
    city: 'City of Parañaque',
    lat: '14.4667',
    lng: '121.0167',
  },
  {
    city: 'Dasmariñas',
    lat: '14.3294',
    lng: '120.9367',
  },
  {
    city: 'Valenzuela',
    lat: '14.7000',
    lng: '120.9833',
  },
  {
    city: 'Bacoor',
    lat: '14.4624',
    lng: '120.9645',
  },
  {
    city: 'General Santos',
    lat: '6.1167',
    lng: '125.1667',
  },
  {
    city: 'Las Piñas City',
    lat: '14.4500',
    lng: '120.9833',
  },
  {
    city: 'Makati City',
    lat: '14.5500',
    lng: '121.0333',
  },
  {
    city: 'San Jose del Monte',
    lat: '14.8139',
    lng: '121.0453',
  },
  {
    city: 'Bacolod',
    lat: '10.6765',
    lng: '122.9509',
  },
  {
    city: 'Muntinlupa City',
    lat: '14.3833',
    lng: '121.0500',
  },
  {
    city: 'City of Calamba',
    lat: '14.2167',
    lng: '121.1667',
  },
  {
    city: 'Marikina City',
    lat: '14.6500',
    lng: '121.1000',
  },
  {
    city: 'Iloilo',
    lat: '10.7167',
    lng: '122.5667',
  },
  {
    city: 'Pasay City',
    lat: '14.5500',
    lng: '121.0000',
  },
  {
    city: 'Angeles City',
    lat: '15.1472',
    lng: '120.5847',
  },
  {
    city: 'Lapu-Lapu City',
    lat: '10.3127',
    lng: '123.9488',
  },
  {
    city: 'Imus',
    lat: '14.4297',
    lng: '120.9367',
  },
  {
    city: 'Mandaluyong City',
    lat: '14.5833',
    lng: '121.0333',
  },
  {
    city: 'Rodriguez',
    lat: '14.7167',
    lng: '121.1167',
  },
  {
    city: 'Malabon',
    lat: '14.6625',
    lng: '120.9567',
  },
  {
    city: 'Mandaue City',
    lat: '10.3333',
    lng: '123.9333',
  },
  {
    city: 'Santa Rosa',
    lat: '14.3167',
    lng: '121.1167',
  },
  {
    city: 'Baguio City',
    lat: '16.4152',
    lng: '120.5956',
  },
  {
    city: 'Iligan',
    lat: '8.2333',
    lng: '124.2500',
  },
  {
    city: 'Tarlac City',
    lat: '15.4802',
    lng: '120.5979',
  },
  {
    city: 'Butuan',
    lat: '8.9534',
    lng: '125.5288',
  },
  {
    city: 'Biñan',
    lat: '14.3333',
    lng: '121.0833',
  },
  {
    city: 'Lipa City',
    lat: '13.9411',
    lng: '121.1622',
  },
  {
    city: 'Batangas',
    lat: '13.7500',
    lng: '121.0500',
  },
  {
    city: 'San Pedro',
    lat: '14.3583',
    lng: '121.0583',
  },
  {
    city: 'Cainta',
    lat: '14.5667',
    lng: '121.1167',
  },
  {
    city: 'Taytay',
    lat: '14.5692',
    lng: '121.1325',
  },
  {
    city: 'General Trias',
    lat: '14.3833',
    lng: '120.8833',
  },
  {
    city: 'Cabuyao',
    lat: '14.2750',
    lng: '121.1250',
  },
  {
    city: 'San Fernando',
    lat: '15.0333',
    lng: '120.6833',
  },
  {
    city: 'Cabanatuan City',
    lat: '15.4833',
    lng: '120.9667',
  },
  {
    city: 'Cotabato',
    lat: '7.2167',
    lng: '124.2500',
  },
  {
    city: 'Binangonan',
    lat: '14.4514',
    lng: '121.1919',
  },
  {
    city: 'Lucena',
    lat: '13.9333',
    lng: '121.6167',
  },
  {
    city: 'San Pablo',
    lat: '14.0700',
    lng: '121.3250',
  },
  {
    city: 'Tagum',
    lat: '7.4478',
    lng: '125.8078',
  },
  {
    city: 'Santa Maria',
    lat: '14.8183',
    lng: '120.9563',
  },
  {
    city: 'Puerto Princesa',
    lat: '9.7500',
    lng: '118.7500',
  },
  {
    city: 'San Mateo',
    lat: '14.6969',
    lng: '121.1219',
  },
  {
    city: 'Malolos',
    lat: '14.8433',
    lng: '120.8114',
  },
  {
    city: 'Mabalacat',
    lat: '15.2167',
    lng: '120.5833',
  },
  {
    city: 'Navotas',
    lat: '14.6667',
    lng: '120.9417',
  },
  {
    city: 'Silang',
    lat: '14.2306',
    lng: '120.9750',
  },
  {
    city: 'Tacloban',
    lat: '11.2444',
    lng: '125.0039',
  },
  {
    city: 'Olongapo',
    lat: '14.8333',
    lng: '120.2833',
  },
  {
    city: 'Talisay',
    lat: '10.2500',
    lng: '123.8333',
  },
  {
    city: 'Tanza',
    lat: '14.3944',
    lng: '120.8531',
  },
  {
    city: 'Marilao',
    lat: '14.7581',
    lng: '120.9481',
  },
  {
    city: 'Ormoc',
    lat: '11.0167',
    lng: '124.6167',
  },
  {
    city: 'Meycauayan',
    lat: '14.7333',
    lng: '120.9500',
  },
  {
    city: 'Marawi City',
    lat: '8.0000',
    lng: '124.3000',
  },
  {
    city: 'Pagadian',
    lat: '7.8333',
    lng: '123.4333',
  },
  {
    city: 'Legazpi City',
    lat: '13.1333',
    lng: '123.7333',
  },
  {
    city: 'Naga City',
    lat: '13.6167',
    lng: '123.1667',
  },
  {
    city: 'Valencia',
    lat: '7.9000',
    lng: '125.0833',
  },
  {
    city: 'San Carlos City',
    lat: '15.9281',
    lng: '120.3489',
  },
  {
    city: 'Panabo',
    lat: '7.3000',
    lng: '125.6833',
  },
  {
    city: 'Calbayog City',
    lat: '12.0667',
    lng: '124.6000',
  },
  {
    city: 'Kabankalan',
    lat: '9.9833',
    lng: '122.8167',
  },
  {
    city: 'Santo Tomas',
    lat: '14.0833',
    lng: '121.1833',
  },
  {
    city: 'Koronadal',
    lat: '6.5000',
    lng: '124.8500',
  },
  {
    city: 'Malaybalay',
    lat: '8.1575',
    lng: '125.1278',
  },
  {
    city: 'Tanauan',
    lat: '14.0833',
    lng: '121.1500',
  },
  {
    city: 'Dagupan City',
    lat: '16.0333',
    lng: '120.3333',
  },
  {
    city: 'Bago',
    lat: '10.5388',
    lng: '122.8384',
  },
  {
    city: 'Toledo',
    lat: '10.3833',
    lng: '123.6500',
  },
  {
    city: 'Digos',
    lat: '6.7500',
    lng: '125.3500',
  },
  {
    city: 'Sorsogon',
    lat: '12.9667',
    lng: '124.0000',
  },
  {
    city: 'Roxas City',
    lat: '11.5833',
    lng: '122.7500',
  },
  {
    city: 'Lubao',
    lat: '14.9333',
    lng: '120.6000',
  },
  {
    city: 'Trece Martires City',
    lat: '14.2833',
    lng: '120.8667',
  },
  {
    city: 'General Mariano Alvarez',
    lat: '14.3000',
    lng: '121.0000',
  },
  {
    city: 'Cadiz',
    lat: '10.9500',
    lng: '123.3000',
  },
  {
    city: 'Mexico',
    lat: '15.0667',
    lng: '120.7167',
  },
  {
    city: 'Pikit',
    lat: '7.0500',
    lng: '124.6667',
  },
  {
    city: 'Concepcion',
    lat: '15.3249',
    lng: '120.6554',
  },
  {
    city: 'Surigao',
    lat: '9.7833',
    lng: '125.4833',
  },
  {
    city: 'San Miguel',
    lat: '15.1458',
    lng: '120.9783',
  },
  {
    city: 'Tuguegarao',
    lat: '17.6167',
    lng: '121.7167',
  },
  {
    city: 'Polomolok',
    lat: '6.2167',
    lng: '125.0667',
  },
  {
    city: 'Midsayap',
    lat: '7.1917',
    lng: '124.5333',
  },
  {
    city: 'Baliuag',
    lat: '14.9500',
    lng: '120.9000',
  },
  {
    city: 'Sariaya',
    lat: '13.9667',
    lng: '121.5333',
  },
  {
    city: 'Sagay',
    lat: '10.9000',
    lng: '123.4167',
  },
  {
    city: 'Ilagan',
    lat: '17.1333',
    lng: '121.8833',
  },
  {
    city: 'San Jose',
    lat: '12.3528',
    lng: '121.0676',
  },
  {
    city: 'Ozamiz City',
    lat: '8.1500',
    lng: '123.8500',
  },
  {
    city: 'Mati',
    lat: '6.9500',
    lng: '126.2333',
  },
  {
    city: 'Capas',
    lat: '15.3312',
    lng: '120.5898',
  },
  {
    city: 'Kidapawan',
    lat: '7.0083',
    lng: '125.0894',
  },
  {
    city: 'San Jose',
    lat: '15.7833',
    lng: '121.0000',
  },
  {
    city: 'Danao',
    lat: '10.5333',
    lng: '123.9333',
  },
  {
    city: 'Santiago',
    lat: '16.6833',
    lng: '121.5500',
  },
  {
    city: 'Nasugbu',
    lat: '14.0667',
    lng: '120.6333',
  },
  {
    city: 'Calapan',
    lat: '13.3667',
    lng: '121.2000',
  },
  {
    city: 'Tabaco',
    lat: '13.3500',
    lng: '123.7333',
  },
  {
    city: 'Arayat',
    lat: '15.1493',
    lng: '120.7692',
  },
  {
    city: 'Urdaneta',
    lat: '15.9761',
    lng: '120.5711',
  },
  {
    city: 'San Carlos',
    lat: '10.4929',
    lng: '123.4095',
  },
  {
    city: 'Minglanilla',
    lat: '10.2450',
    lng: '123.7964',
  },
  {
    city: 'Consolacion',
    lat: '10.4000',
    lng: '123.9500',
  },
  {
    city: 'Dumaguete City',
    lat: '9.3103',
    lng: '123.3081',
  },
  {
    city: 'Dipolog',
    lat: '8.5667',
    lng: '123.3333',
  },
  {
    city: 'Malasiqui',
    lat: '15.9167',
    lng: '120.4167',
  },
  {
    city: 'Hagonoy',
    lat: '14.8333',
    lng: '120.7333',
  },
  {
    city: 'Calabayan',
    lat: '16.7667',
    lng: '121.7833',
  },
  {
    city: 'La Trinidad',
    lat: '16.4621',
    lng: '120.5877',
  },
  {
    city: 'Mariveles',
    lat: '14.4333',
    lng: '120.4833',
  },
  {
    city: 'Silay',
    lat: '10.8000',
    lng: '122.9667',
  },
  {
    city: 'Daraga',
    lat: '13.1619',
    lng: '123.6939',
  },
  {
    city: 'Jolo',
    lat: '6.0500',
    lng: '121.0000',
  },
  {
    city: 'Floridablanca',
    lat: '14.9333',
    lng: '120.5000',
  },
  {
    city: 'Talavera',
    lat: '15.5839',
    lng: '120.9189',
  },
  {
    city: 'Gingoog',
    lat: '8.8167',
    lng: '125.1000',
  },
  {
    city: 'Porac',
    lat: '15.0719',
    lng: '120.5419',
  },
  {
    city: 'San Juan',
    lat: '14.6000',
    lng: '121.0333',
  },
  {
    city: 'San Fernando',
    lat: '16.6167',
    lng: '120.3167',
  },
  {
    city: 'Bocaue',
    lat: '14.8000',
    lng: '120.9333',
  },
  {
    city: 'Carcar',
    lat: '10.1167',
    lng: '123.6333',
  },
  {
    city: 'Poblacion',
    lat: '10.4167',
    lng: '123.9667',
  },
  {
    city: 'Santo Tomas',
    lat: '7.5333',
    lng: '125.6167',
  },
  {
    city: 'Guimba',
    lat: '15.6581',
    lng: '120.7689',
  },
  {
    city: 'Glan',
    lat: '5.8167',
    lng: '125.2000',
  },
  {
    city: 'Bayawan',
    lat: '9.3667',
    lng: '122.8000',
  },
  {
    city: 'Tanay',
    lat: '14.4972',
    lng: '121.2864',
  },
  {
    city: 'Malita',
    lat: '6.4000',
    lng: '125.6000',
  },
  {
    city: 'Santa Cruz',
    lat: '14.2833',
    lng: '121.4167',
  },
  {
    city: 'Candelaria',
    lat: '13.9311',
    lng: '121.4233',
  },
  {
    city: 'Guagua',
    lat: '14.9667',
    lng: '120.6333',
  },
  {
    city: 'Rosario',
    lat: '13.8460',
    lng: '121.2060',
  },
  {
    city: 'Naga',
    lat: '10.2167',
    lng: '123.7500',
  },
  {
    city: 'Angono',
    lat: '14.5234',
    lng: '121.1536',
  },
  {
    city: 'Magalang',
    lat: '15.2167',
    lng: '120.6667',
  },
  {
    city: 'City of Isabela',
    lat: '6.7000',
    lng: '121.9667',
  },
  {
    city: 'Los Baños',
    lat: '14.1667',
    lng: '121.2167',
  },
  {
    city: 'Iriga City',
    lat: '13.4167',
    lng: '123.4167',
  },
  {
    city: 'Candaba',
    lat: '15.0933',
    lng: '120.8283',
  },
  {
    city: 'Naic',
    lat: '14.3167',
    lng: '120.7667',
  },
  {
    city: 'Ligao',
    lat: '13.2167',
    lng: '123.5167',
  },
  {
    city: 'Norzagaray',
    lat: '14.9167',
    lng: '121.0500',
  },
  {
    city: 'Laoag',
    lat: '18.1951',
    lng: '120.5918',
  },
  {
    city: 'Rosario',
    lat: '14.4167',
    lng: '120.8500',
  },
  {
    city: 'Tabuk',
    lat: '17.4500',
    lng: '121.4583',
  },
  {
    city: 'Gapan',
    lat: '15.3075',
    lng: '120.9453',
  },
  {
    city: 'Baybay',
    lat: '10.6833',
    lng: '124.8000',
  },
  {
    city: 'Calumpit',
    lat: '14.9167',
    lng: '120.7667',
  },
  {
    city: 'Libmanan',
    lat: '13.7000',
    lng: '123.0667',
  },
  {
    city: 'San Juan',
    lat: '13.8260',
    lng: '121.3960',
  },
  {
    city: 'Apalit',
    lat: '14.9496',
    lng: '120.7587',
  },
  {
    city: 'Plaridel',
    lat: '14.8869',
    lng: '120.8569',
  },
  {
    city: 'Himamaylan',
    lat: '10.1000',
    lng: '122.8667',
  },
  {
    city: 'Dinalupihan',
    lat: '14.8833',
    lng: '120.4667',
  },
  {
    city: 'Mangaldan',
    lat: '16.0700',
    lng: '120.4025',
  },
  {
    city: 'Tagbilaran City',
    lat: '9.6500',
    lng: '123.8500',
  },
  {
    city: 'Daet',
    lat: '14.1167',
    lng: '122.9500',
  },
  {
    city: 'Subic',
    lat: '14.9000',
    lng: '120.2333',
  },
  {
    city: 'San Ildefonso',
    lat: '15.0789',
    lng: '120.9419',
  },
  {
    city: 'Samal',
    lat: '7.0500',
    lng: '125.7333',
  },
  {
    city: 'Quezon',
    lat: '7.7333',
    lng: '125.1000',
  },
  {
    city: 'Catbalogan',
    lat: '11.7833',
    lng: '124.8833',
  },
  {
    city: 'Maluñgun',
    lat: '6.2667',
    lng: '125.2833',
  },
  {
    city: 'Lingayen',
    lat: '16.0167',
    lng: '120.2333',
  },
  {
    city: 'Bayugan',
    lat: '8.7143',
    lng: '125.7481',
  },
  {
    city: 'Naujan',
    lat: '13.3233',
    lng: '121.3028',
  },
  {
    city: 'Cavite City',
    lat: '14.4833',
    lng: '120.9000',
  },
  {
    city: 'Talisay',
    lat: '10.7333',
    lng: '122.9667',
  },
  {
    city: 'Cawayan',
    lat: '9.9667',
    lng: '122.6167',
  },
  {
    city: 'Maramag',
    lat: '7.7667',
    lng: '125.0000',
  },
  {
    city: 'Bongao',
    lat: '5.0292',
    lng: '119.7731',
  },
  {
    city: 'Manolo Fortich',
    lat: '8.3697',
    lng: '124.8644',
  },
  {
    city: 'Bulan',
    lat: '12.6714',
    lng: '123.8750',
  },
  {
    city: 'Tayabas',
    lat: '14.0167',
    lng: '121.5833',
  },
  {
    city: 'Guiguinto',
    lat: '14.8333',
    lng: '120.8833',
  },
  {
    city: 'Tiaong',
    lat: '13.9500',
    lng: '121.3167',
  },
  {
    city: 'Sindangan',
    lat: '8.2333',
    lng: '123.0000',
  },
  {
    city: 'Tacurong',
    lat: '6.6833',
    lng: '124.6667',
  },
  {
    city: 'Carmona',
    lat: '14.3167',
    lng: '121.0500',
  },
  {
    city: 'Pulilan',
    lat: '14.9020',
    lng: '120.8490',
  },
  {
    city: 'Balanga',
    lat: '14.6833',
    lng: '120.5333',
  },
  {
    city: 'Guihulñgan',
    lat: '10.1167',
    lng: '123.2667',
  },
  {
    city: 'Carmen',
    lat: '7.2000',
    lng: '124.7833',
  },
  {
    city: 'Masbate',
    lat: '12.3667',
    lng: '123.6167',
  },
  {
    city: 'Sultan Kudarat',
    lat: '7.2333',
    lng: '124.2500',
  },
  {
    city: 'Lopez',
    lat: '13.8840',
    lng: '122.2604',
  },
  {
    city: 'Calasiao',
    lat: '16.0167',
    lng: '120.3667',
  },
  {
    city: 'M’lang',
    lat: '6.9500',
    lng: '124.8833',
  },
  {
    city: 'Monkayo',
    lat: '7.8167',
    lng: '126.0500',
  },
  {
    city: 'San Rafael',
    lat: '14.9500',
    lng: '120.9667',
  },
  {
    city: 'Bislig',
    lat: '8.1833',
    lng: '126.3500',
  },
  {
    city: 'Escalante',
    lat: '10.8333',
    lng: '123.5000',
  },
  {
    city: 'Catarman',
    lat: '12.4500',
    lng: '124.6500',
  },
  {
    city: 'Lemery',
    lat: '13.9167',
    lng: '120.8833',
  },
  {
    city: 'Paniqui',
    lat: '15.6667',
    lng: '120.5833',
  },
  {
    city: 'Bauan',
    lat: '13.7917',
    lng: '121.0085',
  },
  {
    city: 'Santa Cruz',
    lat: '6.8333',
    lng: '125.4167',
  },
  {
    city: 'Balayan',
    lat: '13.9333',
    lng: '120.7333',
  },
  {
    city: 'Isulan',
    lat: '6.6333',
    lng: '124.6000',
  },
  {
    city: 'Palimbang',
    lat: '6.2167',
    lng: '124.2000',
  },
  {
    city: 'Alaminos',
    lat: '16.1553',
    lng: '119.9808',
  },
  {
    city: 'Pili',
    lat: '13.5833',
    lng: '123.3000',
  },
  {
    city: 'Parang',
    lat: '7.3744',
    lng: '124.2686',
  },
  {
    city: 'Kabacan',
    lat: '7.1167',
    lng: '124.8167',
  },
  {
    city: 'Oton',
    lat: '10.6931',
    lng: '122.4736',
  },
  {
    city: 'Pandi',
    lat: '14.8667',
    lng: '120.9500',
  },
  {
    city: 'Salaman',
    lat: '6.6333',
    lng: '124.0667',
  },
  {
    city: 'Polangui',
    lat: '13.2922',
    lng: '123.4856',
  },
  {
    city: 'Victorias',
    lat: '10.9000',
    lng: '123.0833',
  },
  {
    city: 'Gerona',
    lat: '15.6000',
    lng: '120.6000',
  },
  {
    city: 'Compostela',
    lat: '7.6667',
    lng: '126.0833',
  },
  {
    city: 'Balamban',
    lat: '10.4667',
    lng: '123.7833',
  },
  {
    city: 'Pinamalayan',
    lat: '13.0000',
    lng: '121.4167',
  },
  {
    city: 'Aroroy',
    lat: '12.5125',
    lng: '123.3989',
  },
  {
    city: 'Pongotan',
    lat: '7.1500',
    lng: '125.9500',
  },
  {
    city: 'Hinigaran',
    lat: '10.2667',
    lng: '122.8500',
  },
  {
    city: 'Maasin',
    lat: '10.1333',
    lng: '124.8500',
  },
  {
    city: 'Surallah',
    lat: '6.3667',
    lng: '124.7333',
  },
  {
    city: 'Daanbantayan',
    lat: '11.3333',
    lng: '124.0167',
  },
  {
    city: 'Banga',
    lat: '6.3000',
    lng: '124.7833',
  },
  {
    city: 'Nabua',
    lat: '13.4083',
    lng: '123.3750',
  },
  {
    city: 'Makilala',
    lat: '6.9667',
    lng: '125.0833',
  },
  {
    city: 'Kawit',
    lat: '14.4333',
    lng: '120.9000',
  },
  {
    city: 'Camiling',
    lat: '15.7000',
    lng: '120.4167',
  },
  {
    city: 'Sablayan',
    lat: '12.8370',
    lng: '120.7829',
  },
  {
    city: 'Binmaley',
    lat: '16.0323',
    lng: '120.2690',
  },
  {
    city: 'Calabanga',
    lat: '13.7167',
    lng: '123.2333',
  },
  {
    city: 'San Fabian',
    lat: '16.1500',
    lng: '120.4500',
  },
  {
    city: 'Baggao',
    lat: '17.8894',
    lng: '121.8709',
  },
  {
    city: 'Prosperidad',
    lat: '8.6057',
    lng: '125.9153',
  },
  {
    city: 'Solana',
    lat: '17.6500',
    lng: '121.6833',
  },
  {
    city: 'Dapitan',
    lat: '8.6549',
    lng: '123.4243',
  },
  {
    city: 'Guinobatan',
    lat: '13.1833',
    lng: '123.6000',
  },
  {
    city: 'Nabunturan',
    lat: '7.6078',
    lng: '125.9664',
  },
  {
    city: 'Bolinao',
    lat: '16.3333',
    lng: '119.8833',
  },
  {
    city: 'Santa Barbara',
    lat: '16.0031',
    lng: '120.4008',
  },
  {
    city: 'Calaca',
    lat: '13.9667',
    lng: '120.8000',
  },
  {
    city: 'Science City of Muñoz',
    lat: '15.7167',
    lng: '120.9000',
  },
  {
    city: 'Murcia',
    lat: '10.6000',
    lng: '123.0333',
  },
  {
    city: 'Maco',
    lat: '7.3619',
    lng: '125.8553',
  },
  {
    city: 'Indanan',
    lat: '6.0000',
    lng: '120.9667',
  },
  {
    city: 'Calatrava',
    lat: '10.6000',
    lng: '123.4833',
  },
  {
    city: 'Kalibo',
    lat: '11.7000',
    lng: '122.3667',
  },
  {
    city: 'Passi',
    lat: '11.1000',
    lng: '122.6333',
  },
  {
    city: 'Tanjay',
    lat: '9.5167',
    lng: '123.1583',
  },
  {
    city: 'Calauan',
    lat: '14.1500',
    lng: '121.3167',
  },
  {
    city: 'Alabel',
    lat: '6.1023',
    lng: '125.2868',
  },
  {
    city: 'Talipao',
    lat: '5.9760',
    lng: '121.1087',
  },
  {
    city: 'Matalam',
    lat: '7.0833',
    lng: '124.9000',
  },
  {
    city: 'Echague',
    lat: '16.7000',
    lng: '121.6500',
  },
  {
    city: 'Bantayan',
    lat: '11.2000',
    lng: '123.7333',
  },
  {
    city: 'Cabiao',
    lat: '15.2500',
    lng: '120.8500',
  },
  {
    city: 'Mabinay',
    lat: '9.7333',
    lng: '122.9167',
  },
  {
    city: 'Bogo',
    lat: '11.0167',
    lng: '124.0000',
  },
  {
    city: 'San Antonio',
    lat: '15.3833',
    lng: '120.8000',
  },
  {
    city: 'Siaton',
    lat: '9.0667',
    lng: '123.0333',
  },
  {
    city: 'Buhi',
    lat: '13.4333',
    lng: '123.5167',
  },
  {
    city: 'Poblacion',
    lat: '6.8000',
    lng: '124.6333',
  },
  {
    city: 'San Jose',
    lat: '13.8772',
    lng: '121.1050',
  },
  {
    city: 'Malapatan',
    lat: '5.9667',
    lng: '125.2833',
  },
  {
    city: 'Bulacan',
    lat: '14.7928',
    lng: '120.8789',
  },
  {
    city: 'Kapalong',
    lat: '7.5854',
    lng: '125.7052',
  },
  {
    city: 'Jose Abad Santos',
    lat: '5.9167',
    lng: '125.6500',
  },
  {
    city: 'Bais',
    lat: '9.5907',
    lng: '123.1213',
  },
  {
    city: 'Macabebe',
    lat: '14.9081',
    lng: '120.7156',
  },
  {
    city: 'Santa Catalina',
    lat: '9.3331',
    lng: '122.8658',
  },
  {
    city: 'Batarasa',
    lat: '8.6667',
    lng: '117.6167',
  },
  {
    city: 'Libon',
    lat: '13.3000',
    lng: '123.4333',
  },
  {
    city: 'Taytay',
    lat: '10.8167',
    lng: '119.5167',
  },
  {
    city: 'Pototan',
    lat: '10.9500',
    lng: '122.6333',
  },
  {
    city: 'Bauang',
    lat: '16.5333',
    lng: '120.3333',
  },
  {
    city: 'Pagbilao',
    lat: '13.9720',
    lng: '121.6870',
  },
  {
    city: 'Robles',
    lat: '10.3500',
    lng: '123.0667',
  },
  {
    city: 'Lamitan',
    lat: '6.6500',
    lng: '122.1333',
  },
  {
    city: 'Carmen',
    lat: '7.3606',
    lng: '125.7064',
  },
  {
    city: 'Ipil',
    lat: '7.7833',
    lng: '122.5833',
  },
  {
    city: 'Pilar',
    lat: '12.9333',
    lng: '123.6833',
  },
  {
    city: 'San Francisco',
    lat: '8.5050',
    lng: '125.9771',
  },
  {
    city: 'Balagtas',
    lat: '14.8145',
    lng: '120.9085',
  },
  {
    city: 'Gumaca',
    lat: '13.9210',
    lng: '122.1002',
  },
  {
    city: 'Barili',
    lat: '10.1167',
    lng: '123.5333',
  },
  {
    city: 'Ubay',
    lat: '10.0560',
    lng: '124.4729',
  },
  {
    city: 'Virac',
    lat: '13.5833',
    lng: '124.2333',
  },
  {
    city: 'Lambunao',
    lat: '11.0500',
    lng: '122.4833',
  },
  {
    city: 'Cabadbaran',
    lat: '9.1228',
    lng: '125.5346',
  },
  {
    city: 'Umingan',
    lat: '15.9000',
    lng: '120.8000',
  },
  {
    city: 'Mangatarem',
    lat: '15.7874',
    lng: '120.2921',
  },
  {
    city: 'Narra',
    lat: '9.2833',
    lng: '118.4167',
  },
  {
    city: 'Jaen',
    lat: '15.3333',
    lng: '120.9000',
  },
  {
    city: 'Tagoloan',
    lat: '8.5333',
    lng: '124.7500',
  },
  {
    city: 'Calauag',
    lat: '13.9575',
    lng: '122.2875',
  },
  {
    city: 'Argao',
    lat: '9.8833',
    lng: '123.6000',
  },
  {
    city: 'Bongabong',
    lat: '12.7167',
    lng: '121.3667',
  },
  {
    city: 'Talakag',
    lat: '8.2336',
    lng: '124.6003',
  },
  {
    city: 'Alicia',
    lat: '16.7787',
    lng: '121.6972',
  },
  {
    city: 'Tagaytay',
    lat: '14.1000',
    lng: '120.9333',
  },
  {
    city: 'Catanauan',
    lat: '13.5917',
    lng: '122.3250',
  },
  {
    city: 'Sipalay',
    lat: '9.7500',
    lng: '122.4000',
  },
  {
    city: 'Tupi',
    lat: '6.3333',
    lng: '124.9500',
  },
  {
    city: 'Pozorrubio',
    lat: '16.1167',
    lng: '120.5500',
  },
  {
    city: 'Manaoag',
    lat: '16.0439',
    lng: '120.4856',
  },
  {
    city: 'Santa Rosa',
    lat: '15.4239',
    lng: '120.9389',
  },
  {
    city: 'Bamban',
    lat: '15.6500',
    lng: '120.2500',
  },
  {
    city: 'Bula',
    lat: '13.4667',
    lng: '123.2833',
  },
  {
    city: 'Baras',
    lat: '14.5167',
    lng: '121.2667',
  },
  {
    city: 'Borongan',
    lat: '11.6000',
    lng: '125.4333',
  },
  {
    city: 'Dumangas',
    lat: '10.8333',
    lng: '122.7167',
  },
  {
    city: 'Infanta',
    lat: '14.7425',
    lng: '121.6494',
  },
  {
    city: 'Bacacay',
    lat: '13.2925',
    lng: '123.7917',
  },
  {
    city: 'Carles',
    lat: '11.5667',
    lng: '123.1333',
  },
  {
    city: 'Limay',
    lat: '14.5619',
    lng: '120.5983',
  },
  {
    city: 'Oas',
    lat: '13.2589',
    lng: '123.4953',
  },
  {
    city: 'Lala',
    lat: '7.9667',
    lng: '123.7500',
  },
  {
    city: 'Siasi',
    lat: '5.5462',
    lng: '120.8145',
  },
  {
    city: 'Tumauini',
    lat: '17.2667',
    lng: '121.8000',
  },
  {
    city: 'Tinambac',
    lat: '13.8167',
    lng: '123.3333',
  },
  {
    city: 'Miagao',
    lat: '10.6442',
    lng: '122.2352',
  },
  {
    city: 'Dalaguete',
    lat: '9.7612',
    lng: '123.5349',
  },
  {
    city: 'Bugallon',
    lat: '15.9167',
    lng: '120.1833',
  },
  {
    city: 'Binalbagan',
    lat: '10.2000',
    lng: '122.8667',
  },
  {
    city: 'Bagumbayan',
    lat: '6.5339',
    lng: '124.5633',
  },
  {
    city: 'Balingasag',
    lat: '8.7500',
    lng: '124.7833',
  },
  {
    city: 'Cawayan',
    lat: '12.0333',
    lng: '123.6833',
  },
  {
    city: 'Talibon',
    lat: '10.1167',
    lng: '124.2833',
  },
  {
    city: 'Don Carlos',
    lat: '7.6833',
    lng: '125.0000',
  },
  {
    city: 'Orani',
    lat: '14.8000',
    lng: '120.5333',
  },
  {
    city: 'Camalig',
    lat: '13.1500',
    lng: '123.6000',
  },
  {
    city: 'Pigcawayan',
    lat: '7.2833',
    lng: '124.4333',
  },
  {
    city: 'Brookes Point',
    lat: '8.7833',
    lng: '117.8333',
  },
  {
    city: 'San Fernando',
    lat: '10.1667',
    lng: '123.7000',
  },
  {
    city: 'Esperanza',
    lat: '6.7167',
    lng: '124.5167',
  },
  {
    city: 'Pinamungahan',
    lat: '10.2667',
    lng: '123.5833',
  },
  {
    city: 'Hermosa',
    lat: '14.8333',
    lng: '120.5000',
  },
  {
    city: 'Lupon',
    lat: '6.8981',
    lng: '126.0096',
  },
  {
    city: 'Aparri',
    lat: '18.3550',
    lng: '121.6419',
  },
  {
    city: 'Indang',
    lat: '14.2000',
    lng: '120.8833',
  },
  {
    city: 'San Pascual',
    lat: '13.8000',
    lng: '121.0333',
  },
  {
    city: 'Roxas',
    lat: '10.3333',
    lng: '119.3333',
  },
  {
    city: 'San Leonardo',
    lat: '15.3667',
    lng: '120.9667',
  },
  {
    city: 'Cuyapo',
    lat: '15.7833',
    lng: '120.6667',
  },
  {
    city: 'Sipocot',
    lat: '13.7667',
    lng: '122.9833',
  },
  {
    city: 'Castillejos',
    lat: '14.9333',
    lng: '120.2000',
  },
  {
    city: 'Pililla',
    lat: '14.4833',
    lng: '121.3000',
  },
  {
    city: 'Alamada',
    lat: '7.3868',
    lng: '124.5534',
  },
  {
    city: 'San Mateo',
    lat: '16.8833',
    lng: '121.5833',
  },
  {
    city: 'La Carlota',
    lat: '10.4167',
    lng: '122.9167',
  },
  {
    city: 'Bongabon',
    lat: '15.6321',
    lng: '121.1448',
  },
  {
    city: 'Rizal',
    lat: '15.6833',
    lng: '121.1667',
  },
  {
    city: 'La Paz',
    lat: '15.4431',
    lng: '120.7289',
  },
  {
    city: 'Janiuay',
    lat: '10.9500',
    lng: '122.5000',
  },
  {
    city: 'Tuburan',
    lat: '10.7333',
    lng: '123.8333',
  },
  {
    city: 'Pateros',
    lat: '14.5417',
    lng: '121.0667',
  },
  {
    city: 'Mauban',
    lat: '14.1911',
    lng: '121.7308',
  },
  {
    city: 'Victoria',
    lat: '15.5781',
    lng: '120.6819',
  },
  {
    city: 'Agoo',
    lat: '16.3220',
    lng: '120.3647',
  },
  {
    city: 'Aliaga',
    lat: '15.4988',
    lng: '120.8410',
  },
  {
    city: 'Atimonan',
    lat: '14.0036',
    lng: '121.9199',
  },
  {
    city: 'Hilongos',
    lat: '10.3667',
    lng: '124.7500',
  },
  {
    city: 'Goa',
    lat: '13.7000',
    lng: '123.5000',
  },
  {
    city: 'Rosales',
    lat: '15.8944',
    lng: '120.6328',
  },
  {
    city: 'Nagcarlan',
    lat: '14.1364',
    lng: '121.4165',
  },
  {
    city: 'Lutayan',
    lat: '6.6000',
    lng: '124.8500',
  },
  {
    city: 'Tangub',
    lat: '8.0667',
    lng: '123.7500',
  },
  {
    city: 'Saravia',
    lat: '10.8833',
    lng: '122.9667',
  },
  {
    city: 'Kapatagan',
    lat: '7.9000',
    lng: '123.7667',
  },
  {
    city: 'Tigbauan',
    lat: '10.6747',
    lng: '122.3776',
  },
  {
    city: 'San Jose',
    lat: '10.7500',
    lng: '121.9500',
  },
  {
    city: 'Villasis',
    lat: '15.9000',
    lng: '120.5833',
  },
  {
    city: 'Patikul',
    lat: '6.0667',
    lng: '121.1000',
  },
  {
    city: 'Parang',
    lat: '5.9167',
    lng: '120.9167',
  },
  {
    city: 'Isabela',
    lat: '10.2000',
    lng: '122.9833',
  },
  {
    city: 'Bay',
    lat: '14.1833',
    lng: '121.2833',
  },
  {
    city: 'Lantapan',
    lat: '8.0005',
    lng: '125.0235',
  },
  {
    city: 'Roxas',
    lat: '17.1167',
    lng: '121.6167',
  },
  {
    city: 'Buenavista',
    lat: '8.9744',
    lng: '125.4090',
  },
  {
    city: 'Tuao',
    lat: '17.7333',
    lng: '121.4500',
  },
  {
    city: 'Bayombong',
    lat: '16.4833',
    lng: '121.1500',
  },
  {
    city: 'Opol',
    lat: '8.5167',
    lng: '124.5667',
  },
  {
    city: 'Aurora',
    lat: '13.3500',
    lng: '122.5167',
  },
  {
    city: 'Laoang',
    lat: '12.5667',
    lng: '125.0167',
  },
  {
    city: 'Kiamba',
    lat: '5.9833',
    lng: '124.6167',
  },
  {
    city: 'Quezon',
    lat: '9.2333',
    lng: '118.0333',
  },
  {
    city: 'Candon',
    lat: '17.2000',
    lng: '120.4500',
  },
  {
    city: 'Bansalan',
    lat: '6.7833',
    lng: '125.2167',
  },
  {
    city: 'Calinog',
    lat: '11.1333',
    lng: '122.5000',
  },
  {
    city: 'Sibalom',
    lat: '10.7833',
    lng: '122.0167',
  },
  {
    city: 'Santa Barbara',
    lat: '10.8231',
    lng: '122.5344',
  },
  {
    city: 'Itogon',
    lat: '16.3667',
    lng: '120.6833',
  },
  {
    city: 'Poblacion',
    lat: '10.2500',
    lng: '123.9500',
  },
  {
    city: 'Jose Pañganiban',
    lat: '14.3000',
    lng: '122.7000',
  },
  {
    city: 'Abuyog',
    lat: '10.7458',
    lng: '125.0122',
  },
  {
    city: 'Gubat',
    lat: '12.9167',
    lng: '124.1167',
  },
  {
    city: 'Solano',
    lat: '16.5239',
    lng: '121.1919',
  },
  {
    city: 'Maasin',
    lat: '5.8667',
    lng: '125.0000',
  },
  {
    city: 'Sibulan',
    lat: '9.3500',
    lng: '123.2833',
  },
  {
    city: 'Cambanugoy',
    lat: '7.5386',
    lng: '125.7508',
  },
  {
    city: 'Angat',
    lat: '14.9281',
    lng: '121.0293',
  },
  {
    city: 'Obando',
    lat: '14.7000',
    lng: '120.9167',
  },
  {
    city: 'Paracale',
    lat: '14.2833',
    lng: '122.7833',
  },
  {
    city: 'Baao',
    lat: '13.4535',
    lng: '123.3654',
  },
  {
    city: 'Cabatuan',
    lat: '10.8833',
    lng: '122.4833',
  },
  {
    city: 'Mamungan',
    lat: '8.1167',
    lng: '124.2167',
  },
  {
    city: 'Ragay',
    lat: '13.8183',
    lng: '122.7923',
  },
  {
    city: 'Santa Cruz',
    lat: '15.7667',
    lng: '119.9167',
  },
  {
    city: 'Morong',
    lat: '14.5119',
    lng: '121.2389',
  },
  {
    city: 'Palompon',
    lat: '11.0500',
    lng: '124.3833',
  },
  {
    city: 'Santo Domingo',
    lat: '15.5833',
    lng: '120.8667',
  },
  {
    city: 'Castilla',
    lat: '12.9486',
    lng: '123.8822',
  },
  {
    city: 'Moncada',
    lat: '15.7333',
    lng: '120.5667',
  },
  {
    city: 'Teresa',
    lat: '14.5586',
    lng: '121.2083',
  },
  {
    city: 'Botolan',
    lat: '15.2896',
    lng: '120.0245',
  },
  {
    city: 'San Remigio',
    lat: '11.0000',
    lng: '123.9500',
  },
  {
    city: 'Milagros',
    lat: '12.2333',
    lng: '123.5000',
  },
  {
    city: 'Ilog',
    lat: '10.0333',
    lng: '122.7667',
  },
  {
    city: 'Asingan',
    lat: '16.0023',
    lng: '120.6695',
  },
  {
    city: 'Masantol',
    lat: '14.9000',
    lng: '120.7167',
  },
  {
    city: 'Jinoba-an',
    lat: '9.6018',
    lng: '122.4668',
  },
  {
    city: 'Matanao',
    lat: '6.7500',
    lng: '125.2333',
  },
  {
    city: 'Irosin',
    lat: '12.7000',
    lng: '124.0333',
  },
  {
    city: 'Gattaran',
    lat: '18.0667',
    lng: '121.6500',
  },
  {
    city: 'Kananya',
    lat: '11.1833',
    lng: '124.5667',
  },
  {
    city: 'Tulunan',
    lat: '6.8333',
    lng: '124.8833',
  },
  {
    city: 'Calatagan',
    lat: '13.8322',
    lng: '120.6322',
  },
  {
    city: 'Santa Cruz',
    lat: '13.4833',
    lng: '122.0333',
  },
  {
    city: 'Tandag',
    lat: '9.0667',
    lng: '126.1833',
  },
  {
    city: 'Taal',
    lat: '13.8833',
    lng: '120.9333',
  },
  {
    city: 'Malvar',
    lat: '14.0417',
    lng: '121.1583',
  },
  {
    city: 'Baganga',
    lat: '7.5752',
    lng: '126.5585',
  },
  {
    city: 'Uson',
    lat: '12.2253',
    lng: '123.7834',
  },
  {
    city: 'San Fernando',
    lat: '7.9167',
    lng: '125.3333',
  },
  {
    city: 'Orion',
    lat: '14.6206',
    lng: '120.5817',
  },
  {
    city: 'Placer',
    lat: '11.8667',
    lng: '123.9167',
  },
  {
    city: 'Pavia',
    lat: '10.7750',
    lng: '122.5417',
  },
  {
    city: 'Basey',
    lat: '11.2817',
    lng: '125.0683',
  },
  {
    city: 'Lagonoy',
    lat: '13.7333',
    lng: '123.5167',
  },
  {
    city: 'Rosario',
    lat: '16.2333',
    lng: '120.4833',
  },
  {
    city: 'San Mariano',
    lat: '16.9833',
    lng: '122.0167',
  },
  {
    city: 'Medellin',
    lat: '11.1286',
    lng: '123.9622',
  },
  {
    city: 'Tigaon',
    lat: '13.6333',
    lng: '123.5000',
  },
  {
    city: 'Alangalang',
    lat: '11.2000',
    lng: '124.8500',
  },
  {
    city: 'Batac',
    lat: '18.0554',
    lng: '120.5649',
  },
  {
    city: 'San Francisco',
    lat: '10.6500',
    lng: '124.3500',
  },
  {
    city: 'Santa Ana',
    lat: '15.0939',
    lng: '120.7681',
  },
  {
    city: 'Sigaboy',
    lat: '6.6500',
    lng: '126.0667',
  },
  {
    city: 'Tanauan',
    lat: '11.1167',
    lng: '125.0167',
  },
  {
    city: 'Manapla',
    lat: '10.9580',
    lng: '123.1230',
  },
  {
    city: 'New Corella',
    lat: '7.5866',
    lng: '125.8237',
  },
  {
    city: 'Esperanza',
    lat: '8.6760',
    lng: '125.6454',
  },
  {
    city: 'Boac',
    lat: '13.4500',
    lng: '121.8333',
  },
  {
    city: 'Naval',
    lat: '11.5833',
    lng: '124.4500',
  },
  {
    city: 'Binalonan',
    lat: '16.0500',
    lng: '120.6000',
  },
  {
    city: 'Mansalay',
    lat: '12.5204',
    lng: '121.4385',
  },
  {
    city: 'Canlaon',
    lat: '10.3833',
    lng: '123.2000',
  },
  {
    city: 'Jasaan',
    lat: '8.6500',
    lng: '124.7500',
  },
  {
    city: 'Naguilian',
    lat: '16.5333',
    lng: '120.4000',
  },
  {
    city: 'Barotac Nuevo',
    lat: '10.9000',
    lng: '122.7000',
  },
  {
    city: 'San Luis',
    lat: '15.0400',
    lng: '120.7919',
  },
  {
    city: 'Vigan',
    lat: '17.5747',
    lng: '120.3869',
  },
  {
    city: 'Magsaysay',
    lat: '6.7667',
    lng: '125.1833',
  },
  {
    city: 'Santa Maria',
    lat: '6.5500',
    lng: '125.4667',
  },
  {
    city: 'Upi',
    lat: '7.0289',
    lng: '124.1650',
  },
  {
    city: 'Bambang',
    lat: '16.3825',
    lng: '121.1100',
  },
  {
    city: 'Hagonoy',
    lat: '6.6833',
    lng: '125.3000',
  },
  {
    city: 'Paombong',
    lat: '14.8311',
    lng: '120.7892',
  },
  {
    city: 'Roxas',
    lat: '12.5833',
    lng: '121.5000',
  },
  {
    city: 'San Simon',
    lat: '14.9980',
    lng: '120.7800',
  },
  {
    city: 'Pangantocan',
    lat: '7.8333',
    lng: '124.8333',
  },
  {
    city: 'Mulanay',
    lat: '13.5222',
    lng: '122.4042',
  },
  {
    city: 'Tiwi',
    lat: '13.4585',
    lng: '123.6805',
  },
  {
    city: 'Guiuan',
    lat: '11.0333',
    lng: '125.7333',
  },
  {
    city: 'Malay',
    lat: '11.9000',
    lng: '121.9167',
  },
  {
    city: 'Ibaan',
    lat: '13.8176',
    lng: '121.1330',
  },
  {
    city: 'San Manuel',
    lat: '16.0656',
    lng: '120.6667',
  },
  {
    city: 'Burauen',
    lat: '10.9833',
    lng: '124.9000',
  },
  {
    city: 'Ramon',
    lat: '16.7833',
    lng: '121.5333',
  },
  {
    city: 'Lian',
    lat: '14.0333',
    lng: '120.6500',
  },
  {
    city: 'Diffun',
    lat: '16.6000',
    lng: '121.4667',
  },
  {
    city: 'Minalabac',
    lat: '13.5667',
    lng: '123.1833',
  },
  {
    city: 'Ajuy',
    lat: '11.1725',
    lng: '123.0196',
  },
  {
    city: 'Bato',
    lat: '13.3561',
    lng: '123.3639',
  },
  {
    city: 'Molave',
    lat: '8.0833',
    lng: '123.4833',
  },
  {
    city: 'San Joaquin',
    lat: '10.6000',
    lng: '122.0833',
  },
  {
    city: 'Pontevedra',
    lat: '10.3667',
    lng: '122.8833',
  },
  {
    city: 'Alfonso',
    lat: '14.1379',
    lng: '120.8552',
  },
  {
    city: 'Tagkawayan',
    lat: '13.9667',
    lng: '122.5333',
  },
  {
    city: 'Coron',
    lat: '12.0000',
    lng: '120.2000',
  },
  {
    city: 'San Isidro',
    lat: '15.2667',
    lng: '120.9000',
  },
  {
    city: 'Trento',
    lat: '8.0459',
    lng: '126.0614',
  },
  {
    city: 'Lucban',
    lat: '14.1133',
    lng: '121.5569',
  },
  {
    city: 'Carigara',
    lat: '11.3000',
    lng: '124.6833',
  },
  {
    city: 'Cogan',
    lat: '10.5833',
    lng: '123.9667',
  },
  {
    city: 'Tapas',
    lat: '11.2667',
    lng: '122.5333',
  },
  {
    city: 'Dumanjog',
    lat: '10.0500',
    lng: '123.4833',
  },
  {
    city: 'Mercedes',
    lat: '14.1093',
    lng: '123.0109',
  },
  {
    city: 'Aurora',
    lat: '7.9484',
    lng: '123.5819',
  },
  {
    city: 'Iba',
    lat: '15.3333',
    lng: '119.9833',
  },
  {
    city: 'Buenavista',
    lat: '10.7000',
    lng: '122.6333',
  },
  {
    city: 'Cataingan',
    lat: '12.0000',
    lng: '123.9833',
  },
  {
    city: 'Bani',
    lat: '16.1869',
    lng: '119.8592',
  },
  {
    city: 'Pila',
    lat: '14.2333',
    lng: '121.3667',
  },
  {
    city: 'Kitaotao',
    lat: '7.6397',
    lng: '125.0089',
  },
  {
    city: 'El Salvador',
    lat: '8.5667',
    lng: '124.5167',
  },
  {
    city: 'Cabagan',
    lat: '17.4333',
    lng: '121.7667',
  },
  {
    city: 'Urbiztondo',
    lat: '15.8227',
    lng: '120.3295',
  },
  {
    city: 'Buluan',
    lat: '6.7154',
    lng: '124.7854',
  },
  {
    city: 'Leon',
    lat: '10.7808',
    lng: '122.3894',
  },
  {
    city: 'Barobo',
    lat: '8.5500',
    lng: '126.2000',
  },
  {
    city: 'Donsol',
    lat: '12.9167',
    lng: '123.6000',
  },
  {
    city: 'Titay',
    lat: '7.8682',
    lng: '122.5613',
  },
  {
    city: 'Ibajay',
    lat: '11.8167',
    lng: '122.1667',
  },
  {
    city: 'Zaragoza',
    lat: '15.4531',
    lng: '120.7911',
  },
  {
    city: 'Magpet',
    lat: '7.1167',
    lng: '125.1167',
  },
  {
    city: 'Kalamansig',
    lat: '6.5667',
    lng: '124.0500',
  },
  {
    city: 'Pasacao',
    lat: '13.5167',
    lng: '123.0500',
  },
  {
    city: 'Cardona',
    lat: '14.4861',
    lng: '121.2289',
  },
  {
    city: 'Claveria',
    lat: '8.6100',
    lng: '124.8947',
  },
  {
    city: 'Kiblawan',
    lat: '6.6167',
    lng: '125.2167',
  },
  {
    city: 'Libungan',
    lat: '7.2500',
    lng: '124.5167',
  },
  {
    city: 'Hamtic',
    lat: '10.7000',
    lng: '121.9833',
  },
  {
    city: 'Peñablanca',
    lat: '17.6333',
    lng: '121.7833',
  },
  {
    city: 'Estancia',
    lat: '11.4500',
    lng: '123.1500',
  },
  {
    city: 'San Narciso',
    lat: '13.5677',
    lng: '122.5667',
  },
  {
    city: 'Padre Garcia',
    lat: '13.8833',
    lng: '121.2167',
  },
  {
    city: 'Sibonga',
    lat: '10.0333',
    lng: '123.5667',
  },
  {
    city: 'Bangued',
    lat: '17.5965',
    lng: '120.6179',
  },
  {
    city: 'Poblacion',
    lat: '10.4667',
    lng: '123.9667',
  },
  {
    city: 'General Tinio',
    lat: '15.3500',
    lng: '121.0500',
  },
  {
    city: 'Amulung',
    lat: '17.8387',
    lng: '121.7235',
  },
  {
    city: 'Alaminos',
    lat: '14.0635',
    lng: '121.2451',
  },
  {
    city: 'Impasugong',
    lat: '8.3000',
    lng: '125.0000',
  },
  {
    city: 'Asturias',
    lat: '10.5679',
    lng: '123.7172',
  },
  {
    city: 'Bantacan',
    lat: '7.5333',
    lng: '126.1333',
  },
  {
    city: 'Masinloc',
    lat: '15.5333',
    lng: '119.9500',
  },
  {
    city: 'Minalin',
    lat: '14.9667',
    lng: '120.6833',
  },
  {
    city: 'Tuba',
    lat: '16.3167',
    lng: '120.5500',
  },
  {
    city: 'Caramoan',
    lat: '13.7707',
    lng: '123.8631',
  },
  {
    city: 'President Roxas',
    lat: '7.1544',
    lng: '125.0558',
  },
  {
    city: 'Santa Ignacia',
    lat: '15.6167',
    lng: '120.4333',
  },
  {
    city: 'Sison',
    lat: '16.1667',
    lng: '120.5167',
  },
  {
    city: 'Dumingag',
    lat: '8.1667',
    lng: '123.3500',
  },
  {
    city: 'Aringay',
    lat: '16.3982',
    lng: '120.3555',
  },
  {
    city: 'Dulag',
    lat: '10.9525',
    lng: '125.0317',
  },
  {
    city: 'Tubod',
    lat: '8.0500',
    lng: '123.8000',
  },
  {
    city: 'Isabel',
    lat: '10.9333',
    lng: '124.4333',
  },
  {
    city: 'Siocon',
    lat: '7.7000',
    lng: '122.1333',
  },
  {
    city: 'Pio Duran',
    lat: '13.0333',
    lng: '123.4500',
  },
  {
    city: 'Rosario',
    lat: '8.3814',
    lng: '126.0015',
  },
  {
    city: 'San Pascual',
    lat: '13.1333',
    lng: '122.9833',
  },
  {
    city: 'Norala',
    lat: '6.5500',
    lng: '124.6667',
  },
  {
    city: 'Mahayag',
    lat: '8.1333',
    lng: '123.3833',
  },
  {
    city: 'Pontevedra',
    lat: '11.4833',
    lng: '122.8333',
  },
  {
    city: 'Albuera',
    lat: '10.9186',
    lng: '124.6923',
  },
  {
    city: 'Carmen',
    lat: '9.8167',
    lng: '124.2000',
  },
  {
    city: 'Ayungon',
    lat: '9.8584',
    lng: '123.1468',
  },
  {
    city: 'Mabini',
    lat: '13.7167',
    lng: '120.9000',
  },
  {
    city: 'Dumarao',
    lat: '11.2667',
    lng: '122.6833',
  },
  {
    city: 'Panay',
    lat: '11.5500',
    lng: '122.8000',
  },
  {
    city: 'Ocampo',
    lat: '13.5594',
    lng: '123.3761',
  },
  {
    city: 'Tibigan',
    lat: '9.9500',
    lng: '123.9667',
  },
  {
    city: 'Inabanga',
    lat: '10.0333',
    lng: '124.0667',
  },
  {
    city: 'Wao',
    lat: '7.6404',
    lng: '124.7257',
  },
  {
    city: 'Noveleta',
    lat: '14.4333',
    lng: '120.8833',
  },
  {
    city: 'Barotac Viejo',
    lat: '11.0500',
    lng: '122.8500',
  },
  {
    city: 'Jones',
    lat: '16.5583',
    lng: '121.7000',
  },
  {
    city: 'Dauis',
    lat: '9.6167',
    lng: '123.8500',
  },
  {
    city: 'Katipunan',
    lat: '8.5134',
    lng: '123.2847',
  },
  {
    city: 'Odiongan',
    lat: '12.4000',
    lng: '122.0000',
  },
  {
    city: 'Dingle',
    lat: '11.0500',
    lng: '122.6667',
  },
  {
    city: 'Talisay',
    lat: '14.1000',
    lng: '121.0167',
  },
  {
    city: 'Malinao',
    lat: '13.4000',
    lng: '123.7000',
  },
  {
    city: 'Pilar',
    lat: '11.4833',
    lng: '123.0000',
  },
  {
    city: 'Guinayangan',
    lat: '13.9000',
    lng: '122.4500',
  },
  {
    city: 'Bunawan',
    lat: '8.1781',
    lng: '125.9935',
  },
  {
    city: 'Gloria',
    lat: '12.9167',
    lng: '121.4667',
  },
  {
    city: 'New Washington',
    lat: '11.6500',
    lng: '122.4333',
  },
  {
    city: 'Sogod',
    lat: '10.3833',
    lng: '124.9833',
  },
  {
    city: 'Maitum',
    lat: '6.0333',
    lng: '124.4833',
  },
  {
    city: 'Talagutong',
    lat: '6.2667',
    lng: '125.6667',
  },
  {
    city: 'Lal-lo',
    lat: '18.2000',
    lng: '121.6667',
  },
  {
    city: 'Kabasalan',
    lat: '7.7968',
    lng: '122.7627',
  },
  {
    city: 'Balimbing',
    lat: '5.0728',
    lng: '119.8847',
  },
  {
    city: 'Narvacan',
    lat: '17.4175',
    lng: '120.4753',
  },
  {
    city: 'Libona',
    lat: '8.3333',
    lng: '124.7333',
  },
  {
    city: 'Malabang',
    lat: '7.5903',
    lng: '124.0703',
  },
  {
    city: 'Lupao',
    lat: '15.8793',
    lng: '120.8983',
  },
  {
    city: 'Tuy',
    lat: '14.0167',
    lng: '120.7333',
  },
  {
    city: 'Montevista',
    lat: '7.7000',
    lng: '125.9833',
  },
  {
    city: 'Veruela',
    lat: '8.0698',
    lng: '125.9554',
  },
  {
    city: 'Claveria',
    lat: '12.9035',
    lng: '123.2457',
  },
  {
    city: 'Banisilan',
    lat: '7.5000',
    lng: '124.7000',
  },
  {
    city: 'Roseller Lim',
    lat: '7.6568',
    lng: '122.4701',
  },
  {
    city: 'Buguias',
    lat: '16.7167',
    lng: '120.8333',
  },
  {
    city: 'Vinzons',
    lat: '14.1833',
    lng: '122.9000',
  },
  {
    city: 'Alcala',
    lat: '15.8468',
    lng: '120.5218',
  },
  {
    city: 'Tantangan',
    lat: '6.6167',
    lng: '124.7500',
  },
  {
    city: 'Jaro',
    lat: '11.1833',
    lng: '124.7833',
  },
  {
    city: 'Concepcion',
    lat: '11.2000',
    lng: '123.1000',
  },
  {
    city: 'Tayug',
    lat: '16.0267',
    lng: '120.7478',
  },
  {
    city: 'Angadanan',
    lat: '16.7571',
    lng: '121.7479',
  },
  {
    city: 'Mamburao',
    lat: '13.2233',
    lng: '120.5960',
  },
  {
    city: 'Cordon',
    lat: '16.6667',
    lng: '121.4500',
  },
  {
    city: 'Daram',
    lat: '11.6341',
    lng: '124.7947',
  },
  {
    city: 'Dolores',
    lat: '12.0500',
    lng: '125.4833',
  },
  {
    city: 'Manay',
    lat: '7.2167',
    lng: '126.5333',
  },
  {
    city: 'Loreto',
    lat: '8.1856',
    lng: '125.8538',
  },
  {
    city: 'Manjuyod',
    lat: '9.6833',
    lng: '123.1500',
  },
  {
    city: 'Pagsanjan',
    lat: '14.2667',
    lng: '121.4500',
  },
  {
    city: 'Toboso',
    lat: '10.7167',
    lng: '123.5167',
  },
  {
    city: 'Bacnotan',
    lat: '16.7333',
    lng: '120.3833',
  },
  {
    city: 'Lower Tungawan',
    lat: '7.6017',
    lng: '122.4273',
  },
  {
    city: 'Nasipit',
    lat: '8.9884',
    lng: '125.3408',
  },
  {
    city: 'Villaba',
    lat: '11.2167',
    lng: '124.4000',
  },
  {
    city: 'Pilar',
    lat: '14.6667',
    lng: '120.5667',
  },
  {
    city: 'Labangan',
    lat: '7.8667',
    lng: '123.5167',
  },
  {
    city: 'Sumisip',
    lat: '6.4167',
    lng: '121.9833',
  },
  {
    city: 'General Mamerto Natividad',
    lat: '15.6025',
    lng: '121.0515',
  },
  {
    city: 'El Nido',
    lat: '11.1956',
    lng: '119.4075',
  },
  {
    city: 'Kalilangan',
    lat: '7.7500',
    lng: '124.7500',
  },
  {
    city: 'Santa Rita',
    lat: '11.4667',
    lng: '124.9500',
  },
  {
    city: 'Siay',
    lat: '7.7056',
    lng: '122.8641',
  },
  {
    city: 'Lobo',
    lat: '13.6500',
    lng: '121.2500',
  },
  {
    city: 'Aguilar',
    lat: '15.8899',
    lng: '120.2379',
  },
  {
    city: 'President Quirino',
    lat: '6.7000',
    lng: '124.7333',
  },
  {
    city: 'Moises Padilla',
    lat: '10.2667',
    lng: '123.0833',
  },
  {
    city: 'Labason',
    lat: '8.0667',
    lng: '122.5167',
  },
  {
    city: 'Mandaon',
    lat: '12.2259',
    lng: '123.2842',
  },
  {
    city: 'Culasi',
    lat: '11.4272',
    lng: '122.0560',
  },
  {
    city: 'Carranglan',
    lat: '15.9667',
    lng: '121.0667',
  },
  {
    city: 'Banaybanay',
    lat: '6.9699',
    lng: '126.0126',
  },
  {
    city: 'Guambog',
    lat: '7.3000',
    lng: '125.8500',
  },
  {
    city: 'Matnog',
    lat: '12.5833',
    lng: '124.0833',
  },
  {
    city: 'Palayan City',
    lat: '15.5333',
    lng: '121.0833',
  },
  {
    city: 'Basud',
    lat: '14.0667',
    lng: '122.9667',
  },
  {
    city: 'Pananaw',
    lat: '5.9833',
    lng: '121.2500',
  },
  {
    city: 'Proper Bansud',
    lat: '12.8333',
    lng: '121.3667',
  },
  {
    city: 'Santa Rita',
    lat: '14.9953',
    lng: '120.6153',
  },
  {
    city: 'Santo Niño',
    lat: '6.4333',
    lng: '124.6833',
  },
  {
    city: 'San Jacinto',
    lat: '16.0725',
    lng: '120.4411',
  },
  {
    city: 'Santa Elena',
    lat: '14.2000',
    lng: '122.3833',
  },
  {
    city: 'Maria Aurora',
    lat: '15.7967',
    lng: '121.4737',
  },
  {
    city: 'Cateel',
    lat: '7.7833',
    lng: '126.4500',
  },
  {
    city: 'Maluso',
    lat: '6.5500',
    lng: '121.8833',
  },
  {
    city: 'Leyte',
    lat: '11.3667',
    lng: '124.4833',
  },
  {
    city: 'San Jose',
    lat: '13.7000',
    lng: '123.5167',
  },
  {
    city: 'Quezon',
    lat: '15.5500',
    lng: '120.8167',
  },
  {
    city: 'Santo Tomas',
    lat: '14.9667',
    lng: '120.7167',
  },
  {
    city: 'Caraga',
    lat: '7.3333',
    lng: '126.5667',
  },
  {
    city: 'Panitan',
    lat: '11.4667',
    lng: '122.7667',
  },
  {
    city: 'South Upi',
    lat: '6.8548',
    lng: '124.1443',
  },
  {
    city: 'Balabac',
    lat: '7.9833',
    lng: '117.0500',
  },
  {
    city: 'Abucay',
    lat: '14.7222',
    lng: '120.5354',
  },
  {
    city: 'Santa Cruz',
    lat: '17.0833',
    lng: '120.4500',
  },
  {
    city: 'Hinatuan',
    lat: '8.3667',
    lng: '126.3333',
  },
  {
    city: 'Tucuran',
    lat: '7.8500',
    lng: '123.5833',
  },
  {
    city: 'Payabon',
    lat: '9.7667',
    lng: '123.1333',
  },
  {
    city: 'Liloy',
    lat: '8.1167',
    lng: '122.6667',
  },
  {
    city: 'Nueva Valencia',
    lat: '10.5259',
    lng: '122.5398',
  },
  {
    city: 'Llanera',
    lat: '15.6667',
    lng: '121.0167',
  },
  {
    city: 'Pagalungan',
    lat: '7.0592',
    lng: '124.6987',
  },
  {
    city: 'Mambusao',
    lat: '11.4333',
    lng: '122.6000',
  },
  {
    city: 'Kibawe',
    lat: '7.5667',
    lng: '124.9833',
  },
  {
    city: 'Baler',
    lat: '15.7583',
    lng: '121.5625',
  },
  {
    city: 'Tampakan',
    lat: '6.4500',
    lng: '124.9333',
  },
  {
    city: 'Bañga',
    lat: '11.6333',
    lng: '122.3333',
  },
  {
    city: 'Anda',
    lat: '16.2896',
    lng: '119.9491',
  },
  {
    city: 'Bacolor',
    lat: '14.9984',
    lng: '120.6526',
  },
  {
    city: 'Laurel',
    lat: '14.0500',
    lng: '120.9000',
  },
  {
    city: 'Cabatuan',
    lat: '16.9589',
    lng: '121.6692',
  },
  {
    city: 'Villanueva',
    lat: '8.5833',
    lng: '124.7833',
  },
  {
    city: 'Polanco',
    lat: '8.5333',
    lng: '123.3667',
  },
  {
    city: 'San Miguel',
    lat: '8.8833',
    lng: '126.0000',
  },
  {
    city: 'President Manuel Acuña Roxas',
    lat: '8.5196',
    lng: '123.2277',
  },
  {
    city: 'Victoria',
    lat: '14.2250',
    lng: '121.3250',
  },
  {
    city: 'Tagudin',
    lat: '16.9333',
    lng: '120.4500',
  },
  {
    city: 'Balaoan',
    lat: '16.8167',
    lng: '120.4000',
  },
  {
    city: 'Lasam',
    lat: '18.0667',
    lng: '121.6000',
  },
  {
    city: 'Bulalacao',
    lat: '12.3333',
    lng: '121.3500',
  },
  {
    city: 'Socorro',
    lat: '13.0583',
    lng: '121.4117',
  },
  {
    city: 'Santo Tomas',
    lat: '16.2833',
    lng: '120.3833',
  },
  {
    city: 'Tabogon',
    lat: '10.9333',
    lng: '124.0333',
  },
  {
    city: 'Plaridel',
    lat: '8.6214',
    lng: '123.7101',
  },
  {
    city: 'Gonzaga',
    lat: '18.2667',
    lng: '122.0000',
  },
  {
    city: 'Alcala',
    lat: '17.9031',
    lng: '121.6590',
  },
  {
    city: 'Tagbina',
    lat: '8.4500',
    lng: '126.1667',
  },
  {
    city: 'Mobo',
    lat: '12.3333',
    lng: '123.6500',
  },
  {
    city: 'San Dionisio',
    lat: '11.2711',
    lng: '123.0948',
  },
  {
    city: 'Romblon',
    lat: '12.5789',
    lng: '122.2747',
  },
  {
    city: 'Mambajao',
    lat: '9.2500',
    lng: '124.7167',
  },
  {
    city: 'Malalag',
    lat: '6.6000',
    lng: '125.4000',
  },
  {
    city: 'Mondragon',
    lat: '12.5167',
    lng: '124.7500',
  },
  {
    city: 'La Libertad',
    lat: '10.0333',
    lng: '123.2167',
  },
  {
    city: 'Dingras',
    lat: '18.1000',
    lng: '120.7000',
  },
  {
    city: 'Naga',
    lat: '7.7887',
    lng: '122.6953',
  },
  {
    city: 'Maddela',
    lat: '16.3500',
    lng: '121.7000',
  },
  {
    city: 'Maayon',
    lat: '11.3833',
    lng: '122.7833',
  },
  {
    city: 'Alimodian',
    lat: '10.8196',
    lng: '122.4322',
  },
  {
    city: 'Talacogon',
    lat: '8.4488',
    lng: '125.7869',
  },
  {
    city: 'Rizal',
    lat: '12.4667',
    lng: '120.9667',
  },
  {
    city: 'Vallehermoso',
    lat: '10.3333',
    lng: '123.3167',
  },
  {
    city: 'Balud',
    lat: '12.0369',
    lng: '123.1935',
  },
  {
    city: 'Siniloan',
    lat: '14.4167',
    lng: '121.4500',
  },
  {
    city: 'Agoncillo',
    lat: '13.9334',
    lng: '120.9285',
  },
  {
    city: 'Taysan',
    lat: '13.7833',
    lng: '121.2000',
  },
  {
    city: 'Las Navas',
    lat: '12.3400',
    lng: '125.0320',
  },
  {
    city: 'Maimbung',
    lat: '5.9333',
    lng: '121.0333',
  },
  {
    city: 'Badian',
    lat: '9.8694',
    lng: '123.3959',
  },
  {
    city: 'Margosatubig',
    lat: '7.5783',
    lng: '123.1659',
  },
  {
    city: 'Valladolid',
    lat: '10.4667',
    lng: '122.8333',
  },
  {
    city: 'Malilipot',
    lat: '13.3167',
    lng: '123.7333',
  },
  {
    city: 'Maragondon',
    lat: '14.2667',
    lng: '120.7333',
  },
  {
    city: 'Kasibu',
    lat: '16.3167',
    lng: '121.2833',
  },
  {
    city: 'Amadeo',
    lat: '14.1728',
    lng: '120.9277',
  },
  {
    city: 'Pamplona',
    lat: '9.4667',
    lng: '123.1167',
  },
  {
    city: 'Clarin',
    lat: '8.2000',
    lng: '123.8500',
  },
  {
    city: 'Cabugao',
    lat: '17.8000',
    lng: '120.4500',
  },
  {
    city: 'Santa Cruz',
    lat: '13.1167',
    lng: '120.8500',
  },
  {
    city: 'Aritao',
    lat: '16.2973',
    lng: '121.0338',
  },
  {
    city: 'Baco',
    lat: '13.3584',
    lng: '121.0977',
  },
  {
    city: 'San Juan',
    lat: '16.6667',
    lng: '120.3333',
  },
  {
    city: 'Patnongon',
    lat: '10.9167',
    lng: '121.9833',
  },
  {
    city: 'Poblacion',
    lat: '7.5000',
    lng: '125.9333',
  },
  {
    city: 'Mapandan',
    lat: '16.0167',
    lng: '120.4500',
  },
  {
    city: 'Maasin',
    lat: '10.8833',
    lng: '122.4333',
  },
  {
    city: 'Rapu-Rapu',
    lat: '13.1833',
    lng: '124.1333',
  },
  {
    city: 'Basilisa',
    lat: '10.0654',
    lng: '125.5968',
  },
  {
    city: 'Mabuhay',
    lat: '7.4176',
    lng: '122.8370',
  },
  {
    city: 'San Andres',
    lat: '13.6000',
    lng: '124.1000',
  },
  {
    city: 'San Nicolas',
    lat: '18.1725',
    lng: '120.5958',
  },
  {
    city: 'Jamindan',
    lat: '11.4000',
    lng: '122.5000',
  },
  {
    city: 'Buug',
    lat: '7.7333',
    lng: '123.0667',
  },
  {
    city: 'Puerto Galera',
    lat: '13.5000',
    lng: '120.9542',
  },
  {
    city: 'Lilio',
    lat: '14.1300',
    lng: '121.4360',
  },
  {
    city: 'Oras',
    lat: '12.1333',
    lng: '125.4333',
  },
  {
    city: 'Bacong',
    lat: '9.2464',
    lng: '123.2948',
  },
  {
    city: 'Manucan',
    lat: '8.5161',
    lng: '123.0917',
  },
  {
    city: 'Nabas',
    lat: '11.8333',
    lng: '122.0833',
  },
  {
    city: 'Madridejos',
    lat: '11.2667',
    lng: '123.7333',
  },
  {
    city: 'Pamplona',
    lat: '13.6000',
    lng: '123.0833',
  },
  {
    city: 'Tambulig',
    lat: '8.0667',
    lng: '123.5333',
  },
  {
    city: 'Lumba-a-Bayabao',
    lat: '7.8833',
    lng: '124.3833',
  },
  {
    city: 'Jordan',
    lat: '10.6000',
    lng: '122.6000',
  },
  {
    city: 'Batobato',
    lat: '6.8244',
    lng: '126.0830',
  },
  {
    city: 'Magsaysay',
    lat: '12.3333',
    lng: '121.1500',
  },
  {
    city: 'Alicia',
    lat: '7.5060',
    lng: '122.9412',
  },
  {
    city: 'Real',
    lat: '14.6667',
    lng: '121.6000',
  },
  {
    city: 'Mankayan',
    lat: '16.8667',
    lng: '120.7833',
  },
  {
    city: 'Bangar',
    lat: '16.9000',
    lng: '120.4167',
  },
  {
    city: 'Enrile',
    lat: '17.5500',
    lng: '121.7000',
  },
  {
    city: 'Luna',
    lat: '16.8500',
    lng: '120.3833',
  },
  {
    city: 'San Andres',
    lat: '13.3667',
    lng: '122.6500',
  },
  {
    city: 'Bantay',
    lat: '17.5833',
    lng: '120.3833',
  },
  {
    city: 'Laur',
    lat: '15.5833',
    lng: '121.1833',
  },
  {
    city: 'San Nicolas',
    lat: '16.0700',
    lng: '120.7653',
  },
  {
    city: 'Borbon',
    lat: '10.8333',
    lng: '124.0000',
  },
  {
    city: 'Dinas',
    lat: '7.6136',
    lng: '123.3389',
  },
  {
    city: 'Bagabag',
    lat: '16.6044',
    lng: '121.2521',
  },
  {
    city: 'Caluya',
    lat: '11.9333',
    lng: '121.5500',
  },
  {
    city: 'Tayasan',
    lat: '9.9167',
    lng: '123.1500',
  },
  {
    city: 'Tago',
    lat: '9.0211',
    lng: '126.2317',
  },
  {
    city: 'Samal',
    lat: '14.7678',
    lng: '120.5431',
  },
  {
    city: 'Buldon',
    lat: '7.5167',
    lng: '124.3667',
  },
  {
    city: 'San Fernando',
    lat: '13.5667',
    lng: '123.1500',
  },
  {
    city: 'Dagami',
    lat: '11.0611',
    lng: '124.9031',
  },
  {
    city: 'Sogod',
    lat: '10.7500',
    lng: '124.0000',
  },
  {
    city: 'Aborlan',
    lat: '9.4386',
    lng: '118.5481',
  },
  {
    city: 'Aurora',
    lat: '16.9918',
    lng: '121.6357',
  },
  {
    city: 'Santo Domingo',
    lat: '13.2350',
    lng: '123.7769',
  },
  {
    city: 'Siayan',
    lat: '8.2519',
    lng: '123.1122',
  },
  {
    city: 'Palauig',
    lat: '15.4333',
    lng: '120.0500',
  },
  {
    city: 'Valencia',
    lat: '9.2833',
    lng: '123.2500',
  },
  {
    city: 'Gasan',
    lat: '13.3167',
    lng: '121.8500',
  },
  {
    city: 'Pola',
    lat: '13.1439',
    lng: '121.4400',
  },
  {
    city: 'San Antonio',
    lat: '14.9486',
    lng: '120.0864',
  },
  {
    city: 'Gutalac',
    lat: '7.9833',
    lng: '122.4000',
  },
  {
    city: 'Sibuco',
    lat: '7.2833',
    lng: '122.0667',
  },
  {
    city: 'Magsaysay',
    lat: '9.0167',
    lng: '125.1833',
  },
  {
    city: 'Sagnay',
    lat: '13.6000',
    lng: '123.5167',
  },
  {
    city: 'Gandara',
    lat: '12.0130',
    lng: '124.8118',
  },
  {
    city: 'Imbatug',
    lat: '8.3128',
    lng: '124.6873',
  },
  {
    city: 'Pandan',
    lat: '11.7167',
    lng: '122.1000',
  },
  {
    city: 'Ballesteros',
    lat: '18.4000',
    lng: '121.5167',
  },
  {
    city: 'Palapag',
    lat: '12.5470',
    lng: '125.1160',
  },
  {
    city: 'Dueñas',
    lat: '11.0667',
    lng: '122.6167',
  },
  {
    city: 'Canaman',
    lat: '13.6500',
    lng: '123.1667',
  },
  {
    city: 'Tabango',
    lat: '11.3167',
    lng: '124.3667',
  },
  {
    city: 'Sual',
    lat: '16.0667',
    lng: '120.1000',
  },
  {
    city: 'Mogpog',
    lat: '13.4833',
    lng: '121.8667',
  },
  {
    city: 'Cabanglasan',
    lat: '8.0667',
    lng: '125.3167',
  },
  {
    city: 'San Enrique',
    lat: '11.0697',
    lng: '122.6567',
  },
  {
    city: 'Jagna',
    lat: '9.6500',
    lng: '124.3667',
  },
  {
    city: 'Guimbal',
    lat: '10.6667',
    lng: '122.3167',
  },
  {
    city: 'Kadingilan',
    lat: '7.6000',
    lng: '124.9167',
  },
  {
    city: 'Olutanga',
    lat: '7.3106',
    lng: '122.8464',
  },
  {
    city: 'San Marcelino',
    lat: '14.9742',
    lng: '120.1573',
  },
  {
    city: 'Bugasong',
    lat: '11.0500',
    lng: '122.0667',
  },
  {
    city: 'Capoocan',
    lat: '11.2833',
    lng: '124.6500',
  },
  {
    city: 'Sulop',
    lat: '6.5986',
    lng: '125.3436',
  },
  {
    city: 'Bayog',
    lat: '7.8474',
    lng: '123.0423',
  },
  {
    city: 'Allacapan',
    lat: '18.2270',
    lng: '121.5556',
  },
  {
    city: 'Panglao',
    lat: '9.5833',
    lng: '123.7500',
  },
  {
    city: 'Languyan',
    lat: '5.2667',
    lng: '120.0833',
  },
  {
    city: 'San Antonio',
    lat: '13.9000',
    lng: '121.3000',
  },
  {
    city: 'Malangas',
    lat: '7.6263',
    lng: '123.0340',
  },
  {
    city: 'Sitangkai',
    lat: '4.6615',
    lng: '119.3919',
  },
  {
    city: 'Columbio',
    lat: '6.7000',
    lng: '124.9333',
  },
  {
    city: 'San Luis',
    lat: '13.8333',
    lng: '120.9333',
  },
  {
    city: 'Matalom',
    lat: '10.2833',
    lng: '124.8000',
  },
  {
    city: 'Balasan',
    lat: '11.4728',
    lng: '123.0878',
  },
  {
    city: 'Pambujan',
    lat: '12.5667',
    lng: '124.9333',
  },
  {
    city: 'Tobias Fornier',
    lat: '10.5167',
    lng: '121.9500',
  },
  {
    city: 'Santa Maria',
    lat: '15.9808',
    lng: '120.7003',
  },
  {
    city: 'Catubig',
    lat: '12.4000',
    lng: '125.0500',
  },
  {
    city: 'Marantao',
    lat: '7.9500',
    lng: '124.2330',
  },
  {
    city: 'Munai',
    lat: '7.9758',
    lng: '124.0636',
  },
  {
    city: 'Basista',
    lat: '15.8524',
    lng: '120.3976',
  },
  {
    city: 'San Quintin',
    lat: '15.9844',
    lng: '120.8150',
  },
  {
    city: 'Medina',
    lat: '8.9167',
    lng: '125.0167',
  },
  {
    city: 'Santa Ana',
    lat: '18.4667',
    lng: '122.1500',
  },
  {
    city: 'Casiguran',
    lat: '12.8667',
    lng: '124.0167',
  },
  {
    city: 'Cuenca',
    lat: '13.9167',
    lng: '121.0500',
  },
  {
    city: 'Claveria',
    lat: '9.5667',
    lng: '125.7333',
  },
  {
    city: 'Barugo',
    lat: '11.3167',
    lng: '124.7333',
  },
  {
    city: 'Banate',
    lat: '11.0500',
    lng: '122.7833',
  },
  {
    city: 'Abulug',
    lat: '18.4441',
    lng: '121.4576',
  },
  {
    city: 'Dao',
    lat: '11.3944',
    lng: '122.6858',
  },
  {
    city: 'Leganes',
    lat: '10.7833',
    lng: '122.5833',
  },
  {
    city: 'Diplahan',
    lat: '7.6939',
    lng: '122.9845',
  },
  {
    city: 'Guindulman',
    lat: '9.7620',
    lng: '124.4880',
  },
  {
    city: 'Initao',
    lat: '8.5000',
    lng: '124.3167',
  },
  {
    city: 'Bonifacio',
    lat: '8.0527',
    lng: '123.6136',
  },
  {
    city: 'Juban',
    lat: '12.8500',
    lng: '123.9833',
  },
  {
    city: 'Bautista',
    lat: '15.7833',
    lng: '120.5000',
  },
  {
    city: 'Jalajala',
    lat: '14.3557',
    lng: '121.3233',
  },
  {
    city: 'Mayantoc',
    lat: '15.6167',
    lng: '120.3833',
  },
  {
    city: 'Vintar',
    lat: '18.2250',
    lng: '120.6500',
  },
  {
    city: 'Bacarra',
    lat: '18.2519',
    lng: '120.6107',
  },
  {
    city: 'Capalonga',
    lat: '14.3333',
    lng: '122.5000',
  },
  {
    city: 'Salug',
    lat: '8.1079',
    lng: '122.7542',
  },
  {
    city: 'Lupi Viejo',
    lat: '13.8167',
    lng: '122.9000',
  },
  {
    city: 'Luuk',
    lat: '5.9676',
    lng: '121.3133',
  },
  {
    city: 'San Luis',
    lat: '8.4964',
    lng: '125.7364',
  },
  {
    city: 'Aloguinsan',
    lat: '10.2229',
    lng: '123.5491',
  },
  {
    city: 'Midsalip',
    lat: '8.0324',
    lng: '123.3145',
  },
  {
    city: 'Batan',
    lat: '11.5833',
    lng: '122.5000',
  },
  {
    city: 'Pinukpuk',
    lat: '17.6000',
    lng: '121.3667',
  },
  {
    city: 'Dumalinao',
    lat: '7.8167',
    lng: '123.3667',
  },
  {
    city: 'Igbaras',
    lat: '10.7167',
    lng: '122.2667',
  },
  {
    city: 'Trinidad',
    lat: '10.0795',
    lng: '124.3432',
  },
  {
    city: 'San Remigio',
    lat: '10.8331',
    lng: '122.0875',
  },
  {
    city: 'Numancia',
    lat: '11.7000',
    lng: '122.3333',
  },
  {
    city: 'Naguilian',
    lat: '17.0167',
    lng: '121.8500',
  },
  {
    city: 'San Manuel',
    lat: '17.0167',
    lng: '121.6333',
  },
  {
    city: 'Balimbing',
    lat: '7.9000',
    lng: '123.8500',
  },
  {
    city: 'Shariff Aguak',
    lat: '6.8647',
    lng: '124.4417',
  },
  {
    city: 'Payao',
    lat: '7.5857',
    lng: '122.8022',
  },
  {
    city: 'San Isidro',
    lat: '11.4167',
    lng: '124.3500',
  },
  {
    city: 'Badoc',
    lat: '17.9267',
    lng: '120.4754',
  },
  {
    city: 'Kalingalan Caluang',
    lat: '5.8833',
    lng: '121.2667',
  },
  {
    city: 'Mendez-Nuñez',
    lat: '14.1286',
    lng: '120.9058',
  },
  {
    city: 'Laoac East',
    lat: '16.0333',
    lng: '120.5500',
  },
  {
    city: 'Cantilan',
    lat: '9.3336',
    lng: '125.9775',
  },
  {
    city: 'Lingig',
    lat: '8.0381',
    lng: '126.4127',
  },
  {
    city: 'Abra de Ilog',
    lat: '13.4448',
    lng: '120.7260',
  },
  {
    city: 'San Vicente',
    lat: '10.5333',
    lng: '119.2833',
  },
  {
    city: 'Calubian',
    lat: '11.4500',
    lng: '124.4167',
  },
  {
    city: 'Simunul',
    lat: '4.8980',
    lng: '119.8213',
  },
  {
    city: 'Milaor',
    lat: '13.6000',
    lng: '123.1833',
  },
  {
    city: 'Moalboal',
    lat: '9.9500',
    lng: '123.4000',
  },
  {
    city: 'Balungao',
    lat: '15.9000',
    lng: '120.7000',
  },
  {
    city: 'Bauko',
    lat: '16.9833',
    lng: '120.8667',
  },
  {
    city: 'Getafe',
    lat: '10.1500',
    lng: '124.1500',
  },
  {
    city: 'Jimalalud',
    lat: '9.9797',
    lng: '123.1999',
  },
  {
    city: 'Balatan',
    lat: '13.3167',
    lng: '123.2333',
  },
  {
    city: 'Sapa Sapa',
    lat: '5.0899',
    lng: '120.2729',
  },
  {
    city: 'Calape',
    lat: '9.8833',
    lng: '123.8833',
  },
  {
    city: 'Lemery',
    lat: '11.2333',
    lng: '122.9333',
  },
  {
    city: 'Santa Maria',
    lat: '14.4750',
    lng: '121.4250',
  },
  {
    city: 'Magsingal',
    lat: '17.6850',
    lng: '120.4244',
  },
  {
    city: 'Lumbang',
    lat: '14.3000',
    lng: '121.4667',
  },
  {
    city: 'Simbahan',
    lat: '6.3000',
    lng: '120.5833',
  },
  {
    city: 'Cabarroguis',
    lat: '16.5833',
    lng: '121.5000',
  },
  {
    city: 'Polillo',
    lat: '14.7167',
    lng: '121.9500',
  },
  {
    city: 'San Roque',
    lat: '12.5330',
    lng: '124.8670',
  },
  {
    city: 'Torrijos',
    lat: '13.3167',
    lng: '122.0833',
  },
  {
    city: 'Catmon',
    lat: '10.6667',
    lng: '123.9500',
  },
  {
    city: 'Mallig',
    lat: '17.2000',
    lng: '121.6167',
  },
  {
    city: 'Sibagat',
    lat: '8.8219',
    lng: '125.6938',
  },
  {
    city: 'Sibutu',
    lat: '4.8500',
    lng: '119.4667',
  },
  {
    city: 'San Jacinto',
    lat: '12.5667',
    lng: '123.7333',
  },
  {
    city: 'Santa Maria',
    lat: '17.3667',
    lng: '120.4833',
  },
  {
    city: 'Damulog',
    lat: '7.4833',
    lng: '124.9333',
  },
  {
    city: 'Sergio Osmeña Sr',
    lat: '8.2988',
    lng: '123.5036',
  },
  {
    city: 'Buguey',
    lat: '18.2882',
    lng: '121.8331',
  },
  {
    city: 'Sigma',
    lat: '11.4214',
    lng: '122.6662',
  },
  {
    city: 'Dimataling',
    lat: '7.5333',
    lng: '123.3667',
  },
  {
    city: 'Caramoran',
    lat: '13.9833',
    lng: '124.1333',
  },
  {
    city: 'Buenavista',
    lat: '13.7394',
    lng: '122.4675',
  },
  {
    city: 'Talayan',
    lat: '6.9844',
    lng: '124.3564',
  },
  {
    city: 'Barira',
    lat: '7.4833',
    lng: '124.3000',
  },
  {
    city: 'Hinunangan',
    lat: '10.4000',
    lng: '125.2000',
  },
  {
    city: 'Talusan',
    lat: '7.4263',
    lng: '122.8084',
  },
  {
    city: 'Pantabangan',
    lat: '15.8167',
    lng: '121.1500',
  },
  {
    city: 'Claveria',
    lat: '18.6000',
    lng: '121.0833',
  },
  {
    city: 'Gamu',
    lat: '17.0500',
    lng: '121.8333',
  },
  {
    city: 'Morong',
    lat: '14.6800',
    lng: '120.2683',
  },
  {
    city: 'Peñaranda',
    lat: '15.3500',
    lng: '121.0000',
  },
  {
    city: 'Merida',
    lat: '10.9098',
    lng: '124.5376',
  },
  {
    city: 'Calintaan',
    lat: '12.5756',
    lng: '120.9428',
  },
  {
    city: 'Matanog',
    lat: '7.4667',
    lng: '124.2500',
  },
  {
    city: 'Dipaculao',
    lat: '15.9833',
    lng: '121.6333',
  },
  {
    city: 'Alubijid',
    lat: '8.5714',
    lng: '124.4751',
  },
  {
    city: 'General Nakar',
    lat: '14.7631',
    lng: '121.6350',
  },
  {
    city: 'President Roxas',
    lat: '11.4300',
    lng: '122.9300',
  },
  {
    city: 'Benito Soliven',
    lat: '16.9833',
    lng: '121.9500',
  },
  {
    city: 'Lianga',
    lat: '8.6330',
    lng: '126.0932',
  },
  {
    city: 'Candijay',
    lat: '9.8180',
    lng: '124.4960',
  },
  {
    city: 'Dumalag',
    lat: '11.3000',
    lng: '122.6167',
  },
  {
    city: 'Tandubas',
    lat: '5.1340',
    lng: '120.3461',
  },
  {
    city: 'Mataas Na Kahoy',
    lat: '13.9667',
    lng: '121.0833',
  },
  {
    city: 'Balindong',
    lat: '7.9167',
    lng: '124.2000',
  },
  {
    city: 'Masiu',
    lat: '7.8167',
    lng: '124.3167',
  },
  {
    city: 'Dasol',
    lat: '15.9896',
    lng: '119.8805',
  },
  {
    city: 'Ivisan',
    lat: '11.5217',
    lng: '122.6908',
  },
  {
    city: 'Pasuquin',
    lat: '18.3333',
    lng: '120.6167',
  },
  {
    city: 'Tudela',
    lat: '8.2472',
    lng: '123.8424',
  },
  {
    city: 'Balete',
    lat: '11.5500',
    lng: '122.3833',
  },
  {
    city: 'Bontoc',
    lat: '10.3500',
    lng: '124.9667',
  },
  {
    city: 'Dolores',
    lat: '14.0157',
    lng: '121.4011',
  },
  {
    city: 'New Panamao',
    lat: '5.9667',
    lng: '121.2000',
  },
  {
    city: 'Siraway',
    lat: '7.5881',
    lng: '122.1424',
  },
  {
    city: 'Lavezares',
    lat: '12.5333',
    lng: '124.3333',
  },
  {
    city: 'Tubao',
    lat: '16.3500',
    lng: '120.4167',
  },
  {
    city: 'Salay',
    lat: '8.8667',
    lng: '124.8000',
  },
  {
    city: 'Anilao',
    lat: '10.9785',
    lng: '122.7531',
  },
  {
    city: 'Santa Fe',
    lat: '11.1500',
    lng: '123.8000',
  },
  {
    city: 'Kumalarang',
    lat: '7.7500',
    lng: '123.1500',
  },
  {
    city: 'Manticao',
    lat: '8.4042',
    lng: '124.2867',
  },
  {
    city: 'Las Nieves',
    lat: '8.7351',
    lng: '125.6010',
  },
  {
    city: 'Saint Bernard',
    lat: '10.2833',
    lng: '125.1333',
  },
  {
    city: 'Datu Paglas',
    lat: '6.7669',
    lng: '124.8500',
  },
  {
    city: 'San Narciso',
    lat: '15.0167',
    lng: '120.0833',
  },
  {
    city: 'Licab',
    lat: '15.5439',
    lng: '120.7634',
  },
  {
    city: 'Libacao',
    lat: '11.4833',
    lng: '122.3000',
  },
  {
    city: 'Villareal',
    lat: '11.5667',
    lng: '124.9333',
  },
  {
    city: 'La Paz',
    lat: '8.2801',
    lng: '125.8092',
  },
  {
    city: 'Macalelon',
    lat: '13.7500',
    lng: '122.1333',
  },
  {
    city: 'Paracelis',
    lat: '17.2667',
    lng: '121.4667',
  },
  {
    city: 'Agno',
    lat: '16.1161',
    lng: '119.8027',
  },
  {
    city: 'Sexmoan',
    lat: '14.9333',
    lng: '120.6167',
  },
  {
    city: 'Santo Domingo',
    lat: '17.6333',
    lng: '120.4083',
  },
  {
    city: 'Oslob',
    lat: '9.5500',
    lng: '123.4000',
  },
  {
    city: 'Caridad',
    lat: '14.4828',
    lng: '120.8958',
  },
  {
    city: 'Pantao-Ragat',
    lat: '8.0500',
    lng: '124.1500',
  },
  {
    city: 'Iguig',
    lat: '17.7500',
    lng: '121.7333',
  },
  {
    city: 'Mahaplag',
    lat: '10.5833',
    lng: '124.9833',
  },
  {
    city: 'Babatngon',
    lat: '11.4207',
    lng: '124.8434',
  },
  {
    city: 'Majayjay',
    lat: '14.1463',
    lng: '121.4729',
  },
  {
    city: 'Aglipay',
    lat: '16.4889',
    lng: '121.5874',
  },
  {
    city: 'Dauin',
    lat: '9.2000',
    lng: '123.2667',
  },
  {
    city: 'Pulupandan',
    lat: '10.5167',
    lng: '122.8000',
  },
  {
    city: 'San Miguel',
    lat: '10.7833',
    lng: '122.4667',
  },
  {
    city: 'Sumilao',
    lat: '8.2872',
    lng: '124.9456',
  },
  {
    city: 'Jimenez',
    lat: '8.3333',
    lng: '123.8333',
  },
  {
    city: 'Aloran',
    lat: '8.4146',
    lng: '123.8228',
  },
  {
    city: 'Zamboanguita',
    lat: '9.1167',
    lng: '123.2000',
  },
  {
    city: 'Dupax Del Norte',
    lat: '16.2864',
    lng: '121.0942',
  },
  {
    city: 'San Jose',
    lat: '10.0083',
    lng: '125.5889',
  },
  {
    city: 'Cuartero',
    lat: '11.3500',
    lng: '122.6667',
  },
  {
    city: 'Ponot',
    lat: '8.4500',
    lng: '123.0333',
  },
  {
    city: 'San Luis',
    lat: '15.7167',
    lng: '121.5167',
  },
  {
    city: 'Lapuyan',
    lat: '7.6333',
    lng: '123.2000',
  },
  {
    city: 'Siquijor',
    lat: '9.1833',
    lng: '123.5500',
  },
  {
    city: 'Bontoc',
    lat: '17.0872',
    lng: '120.9756',
  },
  {
    city: 'Padre Burgos',
    lat: '13.9226',
    lng: '121.8116',
  },
  {
    city: 'Maribojoc',
    lat: '9.7500',
    lng: '123.8500',
  },
  {
    city: 'Baclayon',
    lat: '9.6227',
    lng: '123.9135',
  },
  {
    city: 'Lagawe',
    lat: '16.8167',
    lng: '121.1000',
  },
  {
    city: 'Tingloy',
    lat: '13.6500',
    lng: '120.8667',
  },
  {
    city: 'Anda',
    lat: '9.7420',
    lng: '124.5737',
  },
  {
    city: 'Alcantara',
    lat: '9.9715',
    lng: '123.4047',
  },
  {
    city: 'Agdangan',
    lat: '13.8758',
    lng: '121.9122',
  },
  {
    city: 'Perez',
    lat: '14.1833',
    lng: '121.9333',
  },
  {
    city: 'Padre Burgos',
    lat: '10.0333',
    lng: '125.0167',
  },
  {
    city: 'Basco',
    lat: '20.4500',
    lng: '121.9667',
  },
  {
    city: 'Corella',
    lat: '9.6833',
    lng: '123.9167',
  },
  {
    city: 'Sikatuna',
    lat: '9.6833',
    lng: '123.9667',
  },
  {
    city: 'Oroquieta',
    lat: '8.4859',
    lng: '123.8048',
  },
  {
    city: 'Kabugao',
    lat: '18.0231',
    lng: '121.1840',
  },
  {
    city: 'Santa Cruz',
    lat: '14.1167',
    lng: '121.2833',
  },
  {
    city: 'Koronadal',
    lat: '6.2541',
    lng: '124.9922',
  },
  {
    city: 'San Jose',
    lat: '10.1800',
    lng: '125.5683',
  },
  {
    city: 'Tabuk',
    lat: '17.4084',
    lng: '121.2785',
  },
  {
    city: 'Pili',
    lat: '13.7177',
    lng: '123.7448',
  },
  {
    city: 'Madridejos',
    lat: '9.7912',
    lng: '123.3462',
  }
];
