export enum EnquiryTopic {
  schedule = 'schedule',
  payment = 'payment',
  sales = 'sales',
  info = 'information',
}
